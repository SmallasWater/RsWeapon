package weapon.events;

import cn.nukkit.Player;
import cn.nukkit.event.HandlerList;
import cn.nukkit.event.player.PlayerEvent;
import cn.nukkit.item.Item;

public class PlayerGetWeaponItemEvent extends PlayerEvent {
    private static final HandlerList HANDLER_LIST = new HandlerList();

    public static HandlerList getHandlers() {
        return HANDLER_LIST;
    }
    private Item item;

    public PlayerGetWeaponItemEvent(Player player, Item item){
        this.item = item;
        this.player = player;
    }

    public Item getItem() {
        return item;
    }
}
