package weapon.events;

public class PlayerWeaponClearEvent {
}
