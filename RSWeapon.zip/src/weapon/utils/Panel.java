package weapon.utils;

public class Panel {

}
