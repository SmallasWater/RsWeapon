package weapon.items;

public class ItemLevel {


    private String name;

    public ItemLevel(String name){
        this.name = name;
    }


    public String getName() {
        return name;
    }
}
